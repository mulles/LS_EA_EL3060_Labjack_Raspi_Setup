"""
Package for cross-platform wrapper for the LJM library.

"""

from labjack.ljm.ljm import *


__version__ = "1.1.0"
